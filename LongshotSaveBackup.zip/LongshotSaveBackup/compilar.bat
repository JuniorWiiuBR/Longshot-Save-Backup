@echo off
chcp 65001 >nul
title Compilar Longshot Save Backup
cd /d "%~dp0"

echo ============================================
echo   Longshot Save Backup - gerando o instalador
echo ============================================
echo.

for %%F in (longshot_save_backup.py mods_tab.py mod_manager.py nxsave.py size_table.py installer.py ui_common.py icone.ico background.mp3) do (
    if not exist "%%F" (
        echo ERRO: arquivo "%%F" nao encontrado nesta pasta.
        pause
        exit /b 1
    )
)

set PY=python
%PY% --version >nul 2>&1
if errorlevel 1 (
    set PY=py
    py --version >nul 2>&1
    if errorlevel 1 (
        echo ERRO: Python nao encontrado. Instale o Python e marque "Add to PATH".
        pause
        exit /b 1
    )
)

%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3,14) else 1)" >nul 2>&1
if errorlevel 1 (
    echo AVISO: seu Python e anterior ao 3.14. O programa funciona normalmente, mas a
    echo        tabela de tamanhos dos mods NAO sera gerada. Para ter tudo, use o Python 3.14 ou mais novo.
    echo.
)

echo [1/4] Instalando/atualizando o PyInstaller...
%PY% -m pip install --upgrade pyinstaller
if errorlevel 1 (
    echo ERRO ao instalar o PyInstaller.
    pause
    exit /b 1
)

echo.
echo [2/4] Gerando o programa (LongshotSaveBackup.exe)...
%PY% -m PyInstaller --noconfirm --onefile --noconsole --name "LongshotSaveBackup" --icon "icone.ico" --add-data "icone.ico;." --add-data "background.mp3;." --hidden-import nxsave --hidden-import size_table longshot_save_backup.py
if errorlevel 1 (
    echo ERRO ao compilar o programa.
    pause
    exit /b 1
)
copy /Y "dist\LongshotSaveBackup.exe" "LongshotSaveBackup.exe" >nul

echo.
echo [3/4] Gerando o instalador...
%PY% -m PyInstaller --noconfirm --onefile --noconsole --name "LongshotSaveBackup_Setup" --icon "icone.ico" --add-data "icone.ico;." --add-data "LongshotSaveBackup.exe;." installer.py
if errorlevel 1 (
    echo ERRO ao compilar o instalador.
    pause
    exit /b 1
)
copy /Y "dist\LongshotSaveBackup_Setup.exe" "LongshotSaveBackup_Setup.exe" >nul

echo.
echo [4/4] Limpando arquivos temporarios...
rmdir /S /Q build 2>nul
rmdir /S /Q dist 2>nul
rmdir /S /Q __pycache__ 2>nul
del /Q LongshotSaveBackup.spec 2>nul
del /Q LongshotSaveBackup_Setup.spec 2>nul
del /Q LongshotSaveBackup.exe 2>nul

echo.
echo ============================================
echo   Pronto! Instalador gerado:
echo   LongshotSaveBackup_Setup.exe
echo ============================================
echo.
choice /C SN /M "Abrir o instalador agora"
if errorlevel 2 exit /b 0
start "" "LongshotSaveBackup_Setup.exe"
